package appointify.InstagramBasicApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InstagramBasicAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(InstagramBasicAppApplication.class, args);
	}

}
