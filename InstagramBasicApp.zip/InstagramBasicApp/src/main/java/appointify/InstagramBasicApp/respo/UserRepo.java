package appointify.InstagramBasicApp.respo;

import org.springframework.data.jpa.repository.JpaRepository;

import appointify.InstagramBasicApp.Model.User;

public interface UserRepo extends JpaRepository<User, Integer> {
}
