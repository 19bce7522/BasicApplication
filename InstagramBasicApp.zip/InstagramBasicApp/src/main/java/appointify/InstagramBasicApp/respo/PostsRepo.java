package appointify.InstagramBasicApp.respo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import appointify.InstagramBasicApp.Model.PostEntity;

public interface PostsRepo extends JpaRepository<PostEntity, Integer> {
	
	@Query("SELECT PostEntity pe FROM PostEntity pe where pe.userid=:userid")
	public List<PostEntity> getAllPosts(@Param("userid") Integer userid);
}
