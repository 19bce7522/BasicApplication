package appointify.InstagramBasicApp.controller;

import java.util.List;
import java.util.Optional;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import appointify.InstagramBasicApp.Model.PostEntity;
import appointify.InstagramBasicApp.Model.User;
import appointify.InstagramBasicApp.service.PostsService;
import appointify.InstagramBasicApp.service.UserService;

@RestController
public class BasicController {
	
	@Autowired
	UserService userService;
	
	@Autowired
	PostsService postsService;
	
	@PostMapping("/users")
	public String createUser(@RequestBody User userData)
	{
		userService.createUser(userData);
		return "Created User:"+userData.toString()+" Successfully";
	}
	
	@GetMapping("/users/{id}")
	public Optional<User> getUser(@PathParam("id") Integer id)
	{
		return userService.getUser(id);
	}
	
	@PostMapping("/posts")
	public String savePost(@RequestBody PostEntity entity)
	{
		postsService.createPost(entity);
		return "saved post";
	}
	
	@GetMapping("/posts/{id}")
	public PostEntity getPost(@PathParam("id") Integer id)
	{
		return postsService.getPost(id);
	}
	@GetMapping("/posts/users/{userid}")
	public List<PostEntity> getAllPosts(@PathParam("userid") Integer id)
	{
		return postsService.getAllposts(id);
	}
}
