package appointify.InstagramBasicApp.service;

import appointify.InstagramBasicApp.Model.User;
import appointify.InstagramBasicApp.respo.UserRepo;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
	
	@Autowired
	UserRepo userRepo;
	
	public void createUser(User userData)
	{
		userRepo.save(userData);
	}
	
	public Optional<User> getUser(Integer Id)
	{	
		return userRepo.findById(Id);
	}
}
