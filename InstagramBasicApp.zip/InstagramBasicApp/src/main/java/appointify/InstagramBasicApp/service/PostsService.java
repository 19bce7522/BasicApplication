package appointify.InstagramBasicApp.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import appointify.InstagramBasicApp.Model.PostEntity;
import appointify.InstagramBasicApp.respo.PostsRepo;

@Service
public class PostsService {
	
	@Autowired
	PostsRepo postsRepo;
	
	public void createPost(PostEntity postEntity)
	{
		postEntity.setTimeStamp(new Date().toString());
		postsRepo.save(postEntity);
	}
	
	public PostEntity getPost(Integer id)
	{
		return postsRepo.getById(id);
	}
	
	public List<PostEntity> getAllposts(Integer id)
	{
		return postsRepo.getAllPosts(id);
	}
}
